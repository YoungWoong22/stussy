package com.study.mvc20220927leeyw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mvc20220927LeeywApplicationTests {

	@Test
	void contextLoads() {
	}

}
