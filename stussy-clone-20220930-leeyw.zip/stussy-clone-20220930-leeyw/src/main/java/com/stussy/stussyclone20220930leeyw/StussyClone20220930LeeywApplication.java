package com.stussy.stussyclone20220930leeyw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StussyClone20220930LeeywApplication {

	public static void main(String[] args) {
		SpringApplication.run(StussyClone20220930LeeywApplication.class, args);
	}

}
