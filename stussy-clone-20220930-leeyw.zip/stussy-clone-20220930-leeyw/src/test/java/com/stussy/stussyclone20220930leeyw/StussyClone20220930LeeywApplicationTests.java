package com.stussy.stussyclone20220930leeyw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StussyClone20220930LeeywApplicationTests {

	@Test
	void contextLoads() {
	}

}
